// _ in the name is important otherwise everything would work
package com.bumptech.glide.test._package;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.LibraryGlideModule;

@GlideModule
public final class LibraryModuleInPackage extends LibraryGlideModule {}
