package com.bumptech.glide.annotation.compiler;

@Index(
    modules = "com.bumptech.glide.test.EmptyLibraryModule"
)
public class GlideIndexer_GlideModule_com_bumptech_glide_test_EmptyLibraryModule {
}
